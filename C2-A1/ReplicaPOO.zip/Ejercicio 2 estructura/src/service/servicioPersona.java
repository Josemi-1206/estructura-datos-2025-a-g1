package service;

import model.Persona;

import java.util.ArrayList;
import java.util.List;

public class servicioPersona {
    private List<Persona> personas = new ArrayList<>();

    public void AgregarPersona (Persona persona) { personas.add(persona); }

    public void mostrarInformacion() {
        for (Persona p : personas) {
            p.mostrarInformacion();
            System.out.println();
        }
    }
}
