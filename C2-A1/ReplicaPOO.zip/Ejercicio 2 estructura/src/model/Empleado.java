package model;

public class Empleado extends Persona{
    private int codigoEmpleado;
    private String cargoEmpleado;
    private double salarioMensual;

    public Empleado( String nombre, int edad, String direccion, int codigoEmpleado, String cargoEmpleado, float salarioMensual){
        super(nombre, edad, direccion);
        this.codigoEmpleado = codigoEmpleado;
        this.cargoEmpleado = cargoEmpleado;
        this.salarioMensual = salarioMensual;
    }

    public int getCodigoEmpleado () { return codigoEmpleado; }
    public void setCodigoEmpleado (int codigoEmpleado) { this.codigoEmpleado = codigoEmpleado; }

    public String getCargoEmpleado () { return cargoEmpleado; }
    public void setCargoEmpleado (String cargoEmpleado) { this.cargoEmpleado = cargoEmpleado; }

    public double getSalarioMensual () { return salarioMensual; }
    public void setSalarioMensual (double salarioMensual) { this.salarioMensual = salarioMensual; }

    @Override
    public void mostrarInformacion(){
        System.out.println("Cliente: " + getNombre());
        System.out.println("Edad: " + getEdad());
        System.out.println("Dirección: " + getDireccion());
        System.out.println("Código empleado: " + getCodigoEmpleado());
        System.out.println("Cargo empleado: " + getCargoEmpleado());
        System.out.println("Salario Mensual: " + getSalarioMensual());

    }

}
