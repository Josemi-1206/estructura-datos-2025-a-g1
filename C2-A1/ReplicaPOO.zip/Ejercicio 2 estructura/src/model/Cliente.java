package model;
import java.util.List;

public class Cliente extends Persona{
    private int numeroCliente;
    private List<String> historialCompras;

    public Cliente( String nombre, int edad, String direccion, int numeroCliente, List<String> historialCompras ){
        super(nombre, edad, direccion);
        this.numeroCliente = numeroCliente;
        this.historialCompras = historialCompras;
    }

    public int getNumeroCliente() { return numeroCliente; }
    public void setNumeroCliente(int numeroCliente) { this.numeroCliente = numeroCliente; }

    public List<String> getHistorialCompras() { return historialCompras; }
    public void setHistorialCompras(List<String> historialCompras) { this.historialCompras = historialCompras; }

    @Override
    public void mostrarInformacion(){
        System.out.println("Cliente: " + getNombre());
        System.out.println("Edad: " + getEdad());
        System.out.println("Dirección: " + getDireccion());
        System.out.println("Número cliente: " + getNumeroCliente());
        System.out.println("Historial de Compras: " + getHistorialCompras());
    }


}
