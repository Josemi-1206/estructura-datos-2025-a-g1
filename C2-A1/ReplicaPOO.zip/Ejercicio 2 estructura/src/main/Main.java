package main;

import model.Cliente;
import model.Empleado;
import service.servicioPersona;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        servicioPersona service = new servicioPersona();

        service.AgregarPersona(new Cliente("Juan José", 18, "Calle 25#32-33", 1553, Arrays.asList("Nevera", "Lavadora", "lavaloza")));
        service.AgregarPersona(new Empleado("Brian", 21, "Calle 185 #55-72",7912, "Director", 2100000));

        service.mostrarInformacion();

    }
}
