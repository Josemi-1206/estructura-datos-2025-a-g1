package model;

public class Burro extends Animal {
    private String colorpelaje;

    public Burro(String nombre, int edad, float peso, String colorpelaje){
        super(nombre, edad, peso);
        this.colorpelaje = colorpelaje;
    }

    public String getColorpelaje() { return colorpelaje; }
    public void setColorpelaje(String colorpelaje) {this.colorpelaje = colorpelaje; }

    @Override
     public void comer() {
        System.out.println("Soy un burro y estoy comiendo pasto.");
    }

    @Override
    public void dormir() {
        System.out.println("Estoy durmiendo bajo un árbol.");
    }

    @Override
    public void desplazarse() {
        System.out.println("Estoy caminando lentamente.");
    }
}
